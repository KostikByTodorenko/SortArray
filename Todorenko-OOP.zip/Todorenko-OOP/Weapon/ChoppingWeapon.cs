﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weapon
{
    /// <summary>
    /// Рубящее оружие
    /// </summary>
    class ChoppingWeapon : SteelArms
    {
        private static string _menu;
        /// <summary>
        /// Длина клинка
        /// </summary>
        private int _bladeLength = 0;
        /// <summary>
        /// Заточенность лезвия
        /// </summary>
        private float _bladeSherpness = 0;
        /// <summary>
        /// Вес лезвия
        /// </summary>
        private float _bladeWeigth = 0;


        /// <summary>
        /// Ввод характеристик оружия
        /// </summary>
        public void WeaponsCharacterization()
        {
            Console.WriteLine("Введите название оружия: ");
            Name = Console.ReadLine();
            Console.WriteLine("Введите вес оружия: ");
            Weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите вес лезвия оружия: ");
            BladeWeigth = int.Parse(Console.ReadLine());
            if (BladeWeigth > Weight)
            {
                Console.WriteLine("Вес лезвия больше веса оружия, введите значение заново: ");
                BladeWeigth = int.Parse(Console.ReadLine());
            }
             Console.WriteLine("Введите длину оружия: ");
            Length = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите длину лезвия: ");
            BladeLength = int.Parse(Console.ReadLine());
            if (BladeLength > Length)
            {
                Console.WriteLine("Длина лезвия больше длины оружия, введите значение заново: ");
                BladeLength = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Введите коэффициент заточенности лезвия оружия: ");
            BladeLength = int.Parse(Console.ReadLine());

            Console.WriteLine("");
            Console.WriteLine("Название оружия: {0}", Name);
            Console.WriteLine("Вес оружия: {0} кг", Weight);
            Console.WriteLine("Вес лезвия оружия: {0} кг", BladeWeigth);
            Console.WriteLine("Вес рукоятки оружия: {0} кг", Weight - BladeWeigth);
            Console.WriteLine("Длина оружия: {0} мм", Length);
            Console.WriteLine("Длина лезвия: {0} мм", BladeLength);
            Console.WriteLine("Длина рукоятки оружия: {0} мм", Length - BladeLength);
            Console.WriteLine("Коэффициент заточенности лезвия оружия: {0}", BladeLength);
        }

        /// <summary>
        /// Определение силы удара оружием (измерение в Ньютонах)
        /// </summary>
        /// <returns></returns>
        public float ImpactForce()
        {
            Console.WriteLine("");
            Console.WriteLine("Введите вес оружия: ");
            Weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите степень твердости металла: ");
            HardnessMetal = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите коэффициент заточенности: ");
            BladeSherpness = float.Parse(Console.ReadLine());
            return (Weight * HardnessMetal * BladeSherpness) / 100;
        }

        /// <summary>
        /// Главное меню
        /// </summary>
        public void Menu()
        {
            float _results = 0;

            Console.WriteLine("1. Определение силы удара оружием ");
            Console.WriteLine("2. Ввод информации о оружии");
            _menu = Console.ReadLine();
            if (_menu == "1")
            {
                _results = ImpactForce();
                Console.WriteLine("Сила удара оружием = {0}", _results);
            }else
            {
                WeaponsCharacterization();
            }
        }

        /// <summary>
        /// Длина клинка
        /// </summary>
        public int BladeLength
        {
            get { return _bladeLength; }
            set { _bladeLength = value; }
        }

        /// <summary>
        /// Заточенность лезвия
        /// </summary>
        public float BladeSherpness
        {
            get { return _bladeSherpness; }
            set { _bladeSherpness = value; }
        }

        /// <summary>
        /// Вес лезвия
        /// </summary>
        public float BladeWeigth
        {
            get { return _bladeWeigth; }
            set { _bladeWeigth = value; }
        }
    }
}
