﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weapon
{
    /// <summary>
    /// Запуск приложения
    /// </summary>
    class Runner
    {
        private static string _next;
        private static string _menu;

        /// <summary>
        /// Главное меню
        /// </summary>
        public static void Menu()
        {
            StabbingWeapon stabb = new StabbingWeapon();
            ChoppingWeapon chop = new ChoppingWeapon();
            Console.WriteLine("1. Работа с колющим оружием ");
            Console.WriteLine("2. Работа с рубящим оружием");
            _menu = Console.ReadLine();
            if (_menu == "1")
            {
                stabb.Menu();
            }else
            {
                chop.Menu();
            }
        }

            static void Main(string[] args)
        {       
            do
            {
                Runner.Menu();
                Console.WriteLine("");
                Console.WriteLine("Продолжить (y/n)?");
                _next = Console.ReadLine();
            } while (_next == "y");
        }
    }
}
