﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weapon
{
   /// <summary>
   /// Абстрактный класс оружия, определяющий стандартные характеристики
   /// </summary>
    abstract class HandWeapons
    {
        /// <summary>
        /// Название оружия
        /// </summary>
        private string _name = "";
        /// <summary>
        /// Длина оружия
        /// </summary>
        private int _length = 0;
        /// <summary>
        /// Ширина оружия
        /// </summary>
        private int _width = 0;
        /// <summary>
        /// Вec оружия
        /// </summary>
        private int _weight = 0;

        /// <summary>
        /// Длина оружия
        /// </summary>
        public int Length
        {
            get { return _length; }
            set { _length = value; }
        }
        /// <summary>
        /// Ширина оружия
        /// </summary>
        public int Width
        {
            get { return _width; }
            set { _width = value; }
        }
        /// <summary>
        /// Вес оружия
        /// </summary>
        public int Weight
        {
            get { return _weight; }
            set { _weight = value; }
        }

        /// <summary>
        /// Название оружия
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

    }
}
