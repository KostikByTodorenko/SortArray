﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weapon
{
    /// <summary>
    /// Холодное оружие
    /// </summary>
    class SteelArms : HandWeapons
    {
        /// <summary>
        /// Длина рукоятки
        /// </summary>
        private int _armLength = 0;
        /// <summary>
        /// Твердость металла (иземерние в единицах по Роквеллу)
        /// </summary>
        private int _hardnessMetal = 0;

        /// <summary>
        /// Определение силы удара оружием (измерение в Ньютонах)
        /// </summary>
        /// <returns></returns>
        public int ImpactForce()
        {
            Console.WriteLine("");
            Console.WriteLine("Введите вес оружия: ");
            Weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите степень твердости металла: ");
            HardnessMetal = int.Parse(Console.ReadLine());
            return Weight * HardnessMetal;
        }

        /// <summary>
        /// Длина рукоятки
        /// </summary>
        public int ArmLength
        {
            get { return _armLength; }
            set { _armLength = value; }
        }

        /// <summary>
        /// Твердость металла (иземерние в единицах по Роквеллу)
        /// </summary>
        public int HardnessMetal
        {
            get { return _hardnessMetal; }
            set { _hardnessMetal = value; }
        }

    }
}
