﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weapon
{
    /// <summary>
    /// Колющее оружие
    /// </summary>
    class StabbingWeapon : SteelArms
    {
        private static string _menu;
        /// <summary>
        /// Длина клинка
        /// </summary>
        private int _bladeLength = 0;
        /// <summary>
        /// Заточенность лезвия
        /// </summary>
        private float _bladeSherpness = 0;

        /// <summary>
        /// Ввод характеристик оружия
        /// </summary>
        public void WeaponsCharacterization()
        {
            Console.WriteLine("Введите название оружия: ");
            Name = Console.ReadLine();
            Console.WriteLine("Введите вес оружия: ");
            Weight = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите длину оружия: ");
            Length = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите длину лезвия: ");
            BladeLength = int.Parse(Console.ReadLine());
            while (BladeLength > Length)
            {
                Console.WriteLine("Длина лезвия больше длины оружия, введите значение заново: ");
                BladeLength = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Введите коэффициент заточенности лезвия оружия: ");
            BladeLength = int.Parse(Console.ReadLine());

            Console.WriteLine("\nНазвание оружия: {0}", Name);
            Console.WriteLine("Вес оружия: {0} кг", Weight);
            Console.WriteLine("Длина оружия: {0} мм", Length);
            Console.WriteLine("Длина лезвия: {0} мм", BladeLength);
            Console.WriteLine("Длина рукоятки оружия: {0} мм", Length - BladeLength);
            Console.WriteLine("Коэффициент заточенности лезвия оружия: {0}", BladeLength);
        }

        /// <summary>
        /// Расчет длины лезвия оружия
        /// </summary>
        /// <returns></returns>
        public int CalculationBladeLength()
        {
            Console.WriteLine("\nВведите длину оружия: ");
            Length = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите длину рукоятки оружия: ");
            ArmLength = int.Parse(Console.ReadLine());
            return Length - ArmLength;
        }

        /// <summary>
        /// Расчет проникающей спобосности лезвия
        /// </summary>
        /// <returns></returns>
        public float CalculationPenetratingPower()
        {
            int _power = ImpactForce();
            Console.WriteLine("\nВведите длину лезвия: ");
            BladeLength = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите балл заточенности лезвия: ");
            BladeSherpness = float.Parse(Console.ReadLine());
            return (_power * BladeSherpness * BladeSherpness) / 500;
        }

        /// <summary>
        /// Меню выбора работы с колющим оружием
        /// </summary>
        public void Menu()
        {
            float _results = 0;
            Console.WriteLine("\nРабота с колющим оружие: ");
            Console.WriteLine("1. Расчет длины лезвия оружия ");
            Console.WriteLine("2. Расчет проникающей спобоности лезвия ");
            Console.WriteLine("3. Ввод информации о колющем оружии ");
            Console.WriteLine("4. Работа со списком колющего оружия ");

            _menu = Console.ReadLine();
            switch (_menu)
            {
                case "1": _results = CalculationBladeLength(); Console.WriteLine("Длина лезвия = {0}", _results); break;
                case "2": _results = CalculationPenetratingPower(); Console.WriteLine("Проникающая способность = {0}", _results); break;
                case "3": WeaponsCharacterization(); break;
                default: ListStabbingWeapon(); break;
            }
        }

        /// <summary>
        /// Работа с коллекцией колющего ружия
        /// </summary>
        private void ListStabbingWeapon()
        {
            var stabbingWeapon = new List<StabbingWeapon>
            {
                new StabbingWeapon() {Name = "Рапира", Weight = 3, Width = 12, ArmLength = 20, BladeLength = 40 },
                new StabbingWeapon() {Name = "Пика", Weight = 4, Width = 15, ArmLength = 30, BladeLength = 60 },
                new StabbingWeapon() {Name = "Катана", Weight = 3, Width = 13, ArmLength = 15, BladeLength = 30 },
                new StabbingWeapon() {Name = "Палаш", Weight = 3, Width = 12, ArmLength = 20, BladeLength = 40 },
                new StabbingWeapon() {Name = "Стилет", Weight = 1, Width = 5, ArmLength = 15, BladeLength = 30 }
            };

            Console.WriteLine("1. Вывести список оружия");
            Console.WriteLine("2. Отсортировть список оружия по названию");
            Console.WriteLine("3. Отсортировть список оружия по весу");
            Console.WriteLine("4. Отсортировть список оружия по длине лезвия");

            _menu = Console.ReadLine();
            switch (_menu)
            {
                case "1":
                    break;

                case "2":
                    stabbingWeapon.Sort(delegate (StabbingWeapon sort1, StabbingWeapon sort2)
                    { return sort1.Name.CompareTo(sort2.Name); });
                    break;

                case "3":
                    stabbingWeapon.Sort(delegate (StabbingWeapon sort1, StabbingWeapon sort2)
                    { return sort1.Weight.CompareTo(sort2.Weight); });
                    break;

                default:
                    stabbingWeapon.Sort(delegate (StabbingWeapon sort1, StabbingWeapon sort2)
                    { return sort1.BladeLength.CompareTo(sort2.BladeLength); });
                    break;
            }

            foreach (StabbingWeapon _out in stabbingWeapon)
            {
                Console.WriteLine("\n{0}: вес оружия - {1}, ширина оружия - {2}\nдлина рукоятки - {3}, длина лезвия - {4}  ", _out.Name, _out.Weight, _out.Width, _out.ArmLength, _out.BladeLength);
                Console.WriteLine("----------------------------------------------");
            }
        }
            
        
        
        /// <summary>
        /// Длина лезвия
        /// </summary>
        public int BladeLength
        {
            get { return _bladeLength; }
            set { _bladeLength = value; }
        }

        /// <summary>
        /// Заточенность лезвия
        /// </summary>
        public float BladeSherpness
        {
            get { return _bladeSherpness; }
            set { _bladeSherpness = value; }
        }

 
    }
}
